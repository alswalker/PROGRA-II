package laboratorio.java.swing;
public class LaboratorioJavaSwing {

    public static void main(String[] args) 
    {
       csmenu formulario=new csmenu();
       formulario.setVisible(true);
  
    }
    
}
