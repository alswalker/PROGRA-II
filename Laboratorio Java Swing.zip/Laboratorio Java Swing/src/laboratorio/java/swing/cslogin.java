
package laboratorio.java.swing;

public class cslogin {
    
    String usuario, contraseña;
    boolean v=false;
    

    public cslogin(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public boolean isV() {
        return v;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setV(boolean v) {
        this.v = v;
    }
    
    public boolean validar()
    {
        String u="estudiante";
        String p="UMG2022";
        if(usuario.equals(u)&&contraseña.equals(p))
        {
            v=true;
        }
        else
        {
            v=false;
        }
        return v;
    }

}


