
package laboratorio.java.swing;

public class cstriangulo {
    int a,b,c;

    public cstriangulo(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public int getC() {
        return c;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setB(int b) {
        this.b = b;
    }

    public void setC(int c) {
        this.c = c;
    }

    
    public String ver1() {
        return "Triangulo Equilatero ";    
    }
    public String ver2() {
        return "Triangulo Isoceles ";  
    }
    public String ver3() {
        return "Triangulo Escaleno ";       
    }
    
}
