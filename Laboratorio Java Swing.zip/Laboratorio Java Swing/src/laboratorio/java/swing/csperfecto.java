
package laboratorio.java.swing;

public class csperfecto {
    int n;

    public csperfecto(int n) {
        this.n = n;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }
    
    
     public int calcular(int n)
    {
       int calcular=0;
       for(int i=1;i<n;i++)
       {
           if(n%i==0)
           {
               calcular=calcular+i;
           }
       }
       return calcular;
    }
}
