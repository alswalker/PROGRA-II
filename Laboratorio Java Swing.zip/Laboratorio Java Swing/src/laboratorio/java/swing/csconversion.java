
package laboratorio.java.swing;


public class csconversion 
{
    int cantidad;

    public csconversion(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    public double liarroba()
    {
        double arroba;
        arroba=(this.cantidad/25);
        
        return arroba;
    }
    public double litonelada()
    {
        double tonelada;
        tonelada=(this.cantidad/2204.623);
        
        return tonelada;
    }
      public double alibras()
    {
        double libras;
        libras=(this.cantidad*25);
        
        return libras;
    }
        public double atoneladas()
    {
        double toneladas;
        toneladas=(this.cantidad*0.006901);
        
        return toneladas;
    }
       
        public double tlibras()
    {
        double toneladas;
        toneladas=(this.cantidad*2204.62);
        
        return toneladas;
    }
         
    public double tarroba()
    {
        double arroba;
        arroba=(this.cantidad*40);
        
        return arroba;
    }
}
