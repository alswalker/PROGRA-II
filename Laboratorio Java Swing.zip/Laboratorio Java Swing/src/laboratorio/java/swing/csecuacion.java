package laboratorio.java.swing;

public class csecuacion 
{
    public int a,b,c;

    public csecuacion(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public int getC() {
        return c;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setB(int b) {
        this.b = b;
    }

    public void setC(int c) {
        this.c = c;
    }
    
    public double potencia() 
    {
        double potencia;
        potencia=Math.pow(this.b,2)-(4*this.a*this.c);
        return potencia;      
    }
    public double calcularx1()
    {
        double x1;
        x1=(-this.b-Math.sqrt(potencia())/2*this.a);
        
        return x1;
    }
    public double calcularx2()
    {
        double x2;
        x2=(-this.b+Math.sqrt(potencia())/2*this.a);
        
        return x2;
    }
}
