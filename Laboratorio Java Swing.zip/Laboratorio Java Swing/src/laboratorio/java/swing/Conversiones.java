
package laboratorio.java.swing;

import javax.swing.JOptionPane;

public class Conversiones extends javax.swing.JFrame {

    /**
     * Creates new form Conversiones
     */
    public Conversiones() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        libras = new javax.swing.JRadioButton();
        arrobas = new javax.swing.JRadioButton();
        toneladas = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jtextc = new javax.swing.JTextField();
        jtextlibras = new javax.swing.JTextField();
        jtextarrobas = new javax.swing.JTextField();
        jtexttoneladas = new javax.swing.JTextField();
        btnconvertir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Conversiones"); // NOI18N

        libras.setText("Libras");

        arrobas.setText("Arrobas");

        toneladas.setText("Toneladas");

        jLabel1.setText("Cantidad a convertir");

        jLabel2.setText("Resultado en Libras");

        jLabel3.setText("Resultado en Arrobas");

        jLabel4.setText("Resultado en Toneladas");

        btnconvertir.setText("convertir");
        btnconvertir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconvertirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(libras)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addComponent(arrobas)
                .addGap(38, 38, 38)
                .addComponent(toneladas)
                .addGap(48, 48, 48))
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jtextc, javax.swing.GroupLayout.DEFAULT_SIZE, 76, Short.MAX_VALUE)
                    .addComponent(jtextlibras)
                    .addComponent(jtextarrobas)
                    .addComponent(jtexttoneladas))
                .addGap(79, 79, 79))
            .addGroup(layout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(btnconvertir, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(libras)
                    .addComponent(arrobas)
                    .addComponent(toneladas))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtextc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jtextlibras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtextarrobas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jtexttoneladas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnconvertir)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnconvertirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconvertirActionPerformed
        int cantidad;
        if(libras.isSelected()==true){
            double t,a;
            cantidad= Integer.parseInt(jtextc.getText());
            csconversion c1=new csconversion(cantidad);
            t= c1.liarroba();
            csconversion c2=new csconversion(cantidad);
            a= c2.litonelada();
            jtextarrobas.setText(String.valueOf(t));
            jtexttoneladas.setText(String.valueOf(a));
            jtextlibras.setText(String.valueOf(cantidad));
        }
        else 
              if(arrobas.isSelected()==true){
            double t,a;
            cantidad= Integer.parseInt(jtextc.getText());
            csconversion c1=new csconversion(cantidad);
            t= c1.alibras();
            csconversion c2=new csconversion(cantidad);
            a= c2.atoneladas();
            jtextlibras.setText(String.valueOf(t));
            jtexttoneladas.setText(String.valueOf(a));
            jtextarrobas.setText(String.valueOf(cantidad));
        }
              else 
                if(toneladas.isSelected()==true){
            double t,a;
            cantidad= Integer.parseInt(jtextc.getText());
            csconversion c1=new csconversion(cantidad);
            t= c1.tlibras();
            csconversion c2=new csconversion(cantidad);
            a= c2.tarroba();
            jtextlibras.setText(String.valueOf(t));
            jtextarrobas.setText(String.valueOf(a));
            jtexttoneladas.setText(String.valueOf(cantidad));
        }
        else
                {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado una unidad de medida");
                }
              
    }//GEN-LAST:event_btnconvertirActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Conversiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Conversiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Conversiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Conversiones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Conversiones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton arrobas;
    private javax.swing.JButton btnconvertir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jtextarrobas;
    private javax.swing.JTextField jtextc;
    private javax.swing.JTextField jtextlibras;
    private javax.swing.JTextField jtexttoneladas;
    private javax.swing.JRadioButton libras;
    private javax.swing.JRadioButton toneladas;
    // End of variables declaration//GEN-END:variables
}
