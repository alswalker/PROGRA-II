package laboratorio4parte2;
/**
 *
 * @author alejandro
 */
public class Laboratorio4Parte2 {

    public static void main(String[] args) {
        /*INSTANCIA A MENU*/
        frmMenuPrincipal menu = new frmMenuPrincipal();
        menu.setVisible(true);
    }
    
}
