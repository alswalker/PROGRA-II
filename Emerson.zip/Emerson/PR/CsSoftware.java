package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CsSoftware 
{

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public CsSoftware() 
    {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertar(String TipoSoftW) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_SOFTWARE (TIPO_INCIDENCIA_SW) "
                                        + "VALUES ('" + TipoSoftW + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizar(String TipoSoftW) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_SOFTWARE SET "
                                        + "TIPO_INCIDENCIA_SW = '" + TipoSoftW + " "); //ANTES DEL WHERE NO SE UTILIZA ','
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminar(int IDSW) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_SOFTWARE WHERE ID_SOFTWARE = " + IDSW + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Software> listarSoftware() 
    {
        Software u = null;
        ArrayList<Software> lista = new ArrayList<Software>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOFTWARE");

            while (rs.next()) 
            {
                u = new Software(rs.getString("ID_SOFTWARE"), rs.getString("TIPO_INCIDENCIA_SW"),
                                rs.getInt(1));
                lista.add(u);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Software listarSoftwarePorID(int ID_SOFTWARE) 
    {
        Software u = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOFTWARE HERE ID_SOFTWARE= " + ID_SOFTWARE + "");

            while (rs.next()) 
            {
                u = new Software(rs.getString("ID_SOFTWARE"), rs.getString("TIPO_INCIDENCIA_SW"),
                                             rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            System.out.println(ex.toString());
            return null;
        }
        return u;
    }
}