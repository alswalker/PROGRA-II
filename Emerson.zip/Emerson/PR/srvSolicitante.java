package wsServicios;

import Modelo.Solicitante;
import Modelo.CsSolicitante;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvSolicitante")
public class srvSolicitante 
{

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "Insertar")
    public int insertar(@WebParam(name = "NOMBRES") String NOMBRES) 
                        @WebParam(name = "IDENTIFICACION") String IDENTIFICACION) 
                        @WebParam(name = "CORREO") String CORREO) 
            
    {
       CsSolicitante u = new CsSolicitante();
       return u.insertar(NOMBRES,IDENTIFICACION,CORREO);
    }
    
    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "Actualizar")
    public int actualizar(@WebParam(name = "NOMBRES") String NOMBRES) 
                        @WebParam(name = "IDENTIFICACION") String IDENTIFICACION) 
                        @WebParam(name = "CORREO") String CORREO) 
                        @WebParam(name = "ID_EMPRESA") int ID_EMPRESA) 
    {
        CsSolicitante u = new CsSolicitante();
        return u.actualizar(ID_EMPRESA, NOMBRES,IDENTIFICACION,CORREO);
    }
    
    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "Eliminar")
    public int eliminar  (@WebParam(name = "ID_EMPRESA") int ID_EMPRESA)
    {
        CsSolicitante u = new CsSolicitante();
        return u.eliminar(ID_EMPRESA);
    }
    
    /*--------METODO LIST--------*/    
    @WebMethod(operationName = "Listar")
    public ArrayList<Solicitante> listarSolicitante()
    {
        CsSolicitante u = new CsSolicitante();
        return u.listarSolicitante();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarPorID")
    public Solicitante listarSolicitantePorID (@WebParam(name = "ID_EMPRESA") int ID_EMPRESA)
    {
        CsSolicitante u = new CsSolicitante();
        return u.listarSolicitantePorID(ID_EMPRESA);
    }
}