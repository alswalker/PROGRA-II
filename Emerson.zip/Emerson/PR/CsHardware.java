package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CsHardware
{

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public CsHardware() 
    {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertar(String TipoHardW) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_HARDWARE (TIPO_INCIDENCIA_HW) "
                                        + "VALUES ('" + TipoHardW + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizar(String TipoHardW) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_HARDWARE SET "
                                        + "TIPO_INCIDENCIA_HW = '" + TipoHardW + " "); //ANTES DEL WHERE NO SE UTILIZA ','
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminar(int IDHW) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_HARDWARE WHERE ID_HARDWARE = " + IDHW + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Hardware> listarHardware() 
    {
        Hardware u = null;
        ArrayList<Hardware> lista = new ArrayList<Hardware>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_HARDWARE");

            while (rs.next()) 
            {
                u = new Hardware(rs.getString("ID_HARDWARE"), rs.getString("TIPO_INCIDENCIA_HW"),
                                rs.getInt(1));
                lista.add(u);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Hardware listarHardwarePorID(int ID_HARDWARE) 
    {
        Hardware u = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_HARDWARE HERE ID_HARDWARE= " + ID_HARDWARE + "");

            while (rs.next()) 
            {
                u = new Hardware(rs.getString("ID_HARDWARE"), rs.getString("TIPO_INCIDENCIA_HW"),
                                             rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            System.out.println(ex.toString());
            return null;
        }
        return u;
    }
}