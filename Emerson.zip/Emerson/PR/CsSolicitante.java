package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class CsSolicitante
{

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public CsSolicitante() 
    {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertar(String NOMBRES, String IDENTIFICACION, String CORREO) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_SOLICITANTE (NOMBRES,IDENTIFICACION,CORREO) "
                                        + "VALUES ('" + NOMBRES + "')"
                                        + "VALUES ('" + IDENTIFICACION + "','" + CORREO + ")');
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizar(String ID_EMPRESA, String NOMBRES, String IDENTIFICACION, String CORREO) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_SOLICITANTE SET "
                                        + "NOMBRES = '" + NOMBRES + "',"
                                        + "IDENTIFICACION = '" + IDENTIFICACION + "',"
                                        + "CORREO = '" + CORREO + "',"
                                        + "WHERE ID_EMPRESA = " + ID_EMPRESA + ""); //CON ENTEROS NO SE UTILIZAN ''
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminar(int ID_EMPRESA) 
    {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try 
        {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_SOLICITANTE WHERE ID_EMPRESA = " + ID_EMPRESA + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Solicitante> listarHardware() 
    {
        Solicitante u = null;
        ArrayList<Solicitante> lista = new ArrayList<Solicitante>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOLICITANTE");

            while (rs.next()) 
            {
                u = new Solicitante(rs.getString("ID_EMPRESA"), rs.getString("NOMBRES"),
                                    rs.getString("IDENTIFICACION"), rs.getString("CORREO"),
                                    rs.getInt(1));
                lista.add(u);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Solicitante listarSolicitantePorID(int ID_EMPRESA) 
    {
        Solicitante u = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOLICITANTE HERE ID_EMPRESA= " + ID_EMPRESA + "");

            while (rs.next()) 
            {
                u = new Solicitante(rs.getString("ID_EMPRESA"), rs.getString("TIPO_INCIDENCIA_HW"),
                                    rs.getString("IDENTIFICACION"), rs.getString("CORREO"),
                                    rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) 
        {
            System.out.println(ex.toString());
            return null;
        }
        return u;
    }
}