package wsServicios;

import Modelo.Software;
import Modelo.CsSoftware;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvSoftware")
public class srvSoftware 
{

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "Insertar")
    public int insertar(@WebParam(name = "TIPO_INCIDENCIA_SW") String TipoSoftW)
            
    {
       CsSoftware u = new CsSoftware();
       return u.insertar(TipoSoftW);
    }
    
    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "Actualizar")
    public int actualizar(@WebParam(name = "TIPO_INCIDENCIA_SW") String TipoSoftW, 
                          @WebParam(name = "ID_SOFTWARE") int ID_SOFTWARE) 
    {
        CsSoftware u = new CsSoftware();
        return u.actualizar(TipoSoftW,ID_SOFTWARE);
    }
    
    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "Eliminar")
    public int eliminar  (@WebParam(name = "ID_SOFTWARE") int ID_SOFTWARE)
    {
        CsSoftware u = new CsSoftware();
        return u.eliminar(ID_SOFTWARE);
    }
    
    /*--------METODO LIST--------*/    
    @WebMethod(operationName = "Listar")
    public ArrayList<Software> listarSoftware()
    {
        CsSoftware u = new CsSoftware();
        return u.listarSoftware();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarPorID")
    public Software listarSoftwarePorID (@WebParam(name = "ID_SOFTWARE") int ID_SOFTWARE)
    {
        CsSoftware u = new CsSoftware();
        return u.listarSoftwarePorID(ID_SOFTWARE);
    }
}