package wsServicios;

import Modelo.Hardware;
import Modelo.CsHardware;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvUsuario")
public class srvHardware 
{

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "Insertar")
    public int insertar(@WebParam(name = "TIPO_INCIDENCIA_HW") String TIPO_INCIDENCIA_HW) 
            
    {
       CsHardware u = new CsHardware();
       return u.insertar(TIPO_INCIDENCIA_HW);
    }
    
    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "Actualizar")
    public int actualizar(@WebParam(name = "TIPO_INCIDENCIA_HW") String TIPO_INCIDENCIA_HW, 
                          @WebParam(name = "ID_HARDWARE") int ID_HARDWARE) 
    {
        CsHardware u = new CsHardware();
        return u.actualizar(TIPO_INCIDENCIA_HW, ID_HARDWARE);
    }
    
    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "Eliminar")
    public int eliminar  (@WebParam(name = "ID_HARDWARE") int ID_HARDWARE)
    {
        CsHardware u = new CsHardware();
        return u.eliminar(ID_HARDWARE);
    }
    
    /*--------METODO LIST--------*/    
    @WebMethod(operationName = "Listar")
    public ArrayList<Hardware> listarHardware()
    {
        CsHardware u = new CsHardware();
        return u.listarUsuario();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarPorID")
    public Hardware listarHardwarePorID (@WebParam(name = "ID_HARDWARE") int ID_HARDWARE)
    {
        CsHardware u = new CsHardware();
        return u.listarUsuarioPorID(ID_HARDWARE);
    }
}