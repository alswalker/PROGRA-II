package Modelo;

public class Hardware 
{

    private String TIPO_INCIDENCIA_HW;
    private int ID_HARDWARE;

    /*-----CONSTRUCT-------*/
    public Hardware(String TIPO_INCIDENCIA_HW, int ID_HARDWARE) 
    {
        this.TIPO_INCIDENCIA_HW = TIPO_INCIDENCIA_HW;

        
    }

    /*-----GETTER & SETTER------*/
    public String getTIPO_INCIDENCIA_HW() 
    {
        return TIPO_INCIDENCIA_HW;
    }

    public void setTIPO_INCIDENCIA_HW(String TIPO_INCIDENCIA_HW) 
    {
        this.TIPO_INCIDENCIA_HW = TIPO_INCIDENCIA_HW;
    }


    public int getID_HARDWARE() 
    {
        return ID_HARDWARE;
    }

    public void setID_HARDWARE (int ID_HARDWARE) 
    {
        this.ID_HARDWARE = ID_HARDWARE;
    }
}