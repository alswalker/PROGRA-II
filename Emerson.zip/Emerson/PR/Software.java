package Modelo;

public class Software 
{

    private String TIPO_INCIDENCIA_SW;
    private int ID_SOFTWARE;

    /*-----CONSTRUCT-------*/
    public Software(String TIPO_INCIDENCIA_SW, int ID_SOFTWARE) 
    {
        this.TIPO_INCIDENCIA_SW = TIPO_INCIDENCIA_SW;

        
    }

    /*-----GETTER & SETTER------*/
    public String getTIPO_INCIDENCIA_SW() 
    {
        return TIPO_INCIDENCIA_SW;
    }

    public void setTIPO_INCIDENCIA_SW(String TIPO_INCIDENCIA_SW) 
    {
        this.TIPO_INCIDENCIA_SW = TIPO_INCIDENCIA_SW;
    }


    public int getID_SOFTWARE() 
    {
        return ID_SOFTWARE;
    }

    public void setID_SOFTWARE(int ID_SOFTWARE) 
    {
        this.ID_SOFTWARE = ID_SOFTWARE;
    }
}