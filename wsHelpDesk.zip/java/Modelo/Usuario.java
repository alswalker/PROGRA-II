package Modelo;

public class Usuario {

    private String USUARIO, CONTRASEÑA;
    private int ID_USUARIO;

    /*-----CONSTRUCT-------*/
    public Usuario(String USUARIO, String CONTRASEÑA, int ID_USUARIO) {
        this.USUARIO = USUARIO;
        this.CONTRASEÑA = CONTRASEÑA;
    }

    /*-----GETTER & SETTER------*/
    public String getUSUARIO() {
        return USUARIO;
    }

    public void setUSUARIO(String USUARIO) {
        this.USUARIO = USUARIO;
    }

    public String getCONTRASEÑA() {
        return CONTRASEÑA;
    }

    public void setCONTRASEÑA(String CONTRASEÑA) {
        this.CONTRASEÑA = CONTRASEÑA;
    }

    public int getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_USUARIO(int ID_USUARIO) {
        this.ID_USUARIO = ID_USUARIO;
    }
}
