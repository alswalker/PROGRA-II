package Modelo;

public class Empresa {

    private String NOMBRE_COMERCIAL, NIT, DIRECCION, TELEFONO, CORREO;
    private int ID_EMPRESA;

    /*-----CONSTRUCT-------*/
    public Empresa(String NOMBRE_COMERCIAL, String NIT, String DIRECCION, String TELEFONO, String CORREO, int ID_EMPRESA) {
        this.NOMBRE_COMERCIAL = NOMBRE_COMERCIAL;
        this.NIT = NIT;
        this.DIRECCION = DIRECCION;
        this.TELEFONO = TELEFONO;
        this.CORREO = CORREO;
    }

    /*-----GETTER & SETTER------*/
    public String getNOMBRE_COMERCIAL() {
        return NOMBRE_COMERCIAL;
    }

    public void setNOMBRE_COMERCIAL(String NOMBRE_COMERCIAL) {
        this.NOMBRE_COMERCIAL = NOMBRE_COMERCIAL;
    }

    public String getNIT() {
        return NIT;
    }

    public void setNIT(String NIT) {
        this.NIT = NIT;
    }

    public String getDIRECCION() {
        return DIRECCION;
    }

    public void setDIRECCION(String DIRECCION) {
        this.DIRECCION = DIRECCION;
    }

    public String getTELEFONO() {
        return TELEFONO;
    }

    public void setTELEFONO(String TELEFONO) {
        this.TELEFONO = TELEFONO;
    }

    public String getCORREO() {
        return CORREO;
    }

    public void setCORREO(String CORREO) {
        this.CORREO = CORREO;
    }

    public int getID_EMPRESA() {
        return ID_EMPRESA;
    }

    public void setID_EMPRESA(int ID_EMPRESA) {
        this.ID_EMPRESA = ID_EMPRESA;
    }
}
