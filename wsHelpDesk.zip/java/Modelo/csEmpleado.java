package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csEmpleado {

    private Connection con; //open, close of database
    private Statement stm; //insert, delete, update and select
    private ResultSet rs; //data container.

    public csEmpleado() {
        this.con = null;
        this.stm = null;
    }

    public int insertarEmpleado(int ID_USUARIO, String NOMBRES, String IDENTIFICACION, String CORREO, String PUESTO) {
        int respuesta = 0;
        //instancia de la clase conexion
        csConexion c1 = new csConexion();
        con = c1.conectar();

        try {

            stm = con.createStatement();
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_EMPLEADO (ID_USUARIO,NOMBRES,IDENTIFICACION,CORREO,PUESTO) "
                    + "VALUES (" + ID_USUARIO + ",  "
                    + "'" + NOMBRES + "', "
                    + "'" + IDENTIFICACION + "', "
                    + "'" + CORREO + "' , "
                    + "'" + PUESTO + "' )");
            c1.desconectar();
            con.close();
            stm.close();

        } catch (Exception ex) {
        }
        return respuesta;
    }

    public int actualizarEmpleado(int ID_USUARIO, String NOMBRES, String IDENTIFICACION, String CORREO, String PUESTO, int ID_EMPLEADO) {
        int respuesta = 0;
        csConexion c1 = new csConexion();
        con = c1.conectar();

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_EMPLEADO SET "
                    + "" + "ID_USUARIO= " + ID_USUARIO + " ,"
                    + "NOMBRES ='" + NOMBRES + "', "
                    + "IDENTIFICACION='" + IDENTIFICACION + "', "
                    + "CORREO='" + CORREO + "', "
                    + "PUESTO='" + PUESTO + "' "
                    + "where ID_EMPLEADO=" + ID_EMPLEADO + " ");
            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {
        }
        return respuesta;
    }

    public int eliminarEmpleado(int ID_EMPLEADO) {
        int respuesta = 0;
        csConexion c1 = new csConexion();
        con = c1.conectar();

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_EMPLEADO WHERE ID_EMPLEADO=" + ID_EMPLEADO + " ");
            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return respuesta;
    }

    public ArrayList<Empleado> listarEmpleado() {
        Empleado e = null;
        ArrayList<Empleado> lista = new ArrayList<Empleado>();
        //lista=null;

        csConexion c1 = new csConexion();
        con = c1.conectar();
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_EMPLEADO");
            while (rs.next()) {
                e = new Empleado(rs.getInt(1), rs.getInt(2), rs.getString("NOMBRES"), rs.getString("IDENTIFICACION"), rs.getString("CORREO"), rs.getString("PUESTO"));
                lista.add(e);
            }

            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return lista;
    }

    public Empleado listarEmpleadoPorID(int ID_EMPLEADO) {
        Empleado e = null;

        csConexion c1 = new csConexion();
        con = c1.conectar();
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_EMPLEADO WHERE ID_EMPLEADO=" + ID_EMPLEADO + " ");
            while (rs.next()) {
                e = new Empleado(rs.getInt(1), rs.getInt(2), rs.getString("NOMBRES"), rs.getString("IDENTIFICACION"), rs.getString("CORREO"), rs.getString("PUESTO"));
            }
            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return e;
    }
}
