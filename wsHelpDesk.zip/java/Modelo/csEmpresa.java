package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csEmpresa {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csEmpresa() {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertarEmpresa(String NOMBRE_COMERCIAL, String NIT, String DIRECCION, String TELEFONO, String CORREO) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_EMPRESA (NOMBRE_COMERCIAL, NIT, DIRECCION, TELEFONO, CORREO)"
                    + "VALUES  ('" + NOMBRE_COMERCIAL + "',"
                    + "         '" + NIT + "', "
                    + "         '" + DIRECCION + "', "
                    + "         '" + TELEFONO + "',"
                    + "         '" + CORREO + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizarEmpresa(String NOMBRE_COMERCIAL, String NIT, String DIRECCION, String TELEFONO, String CORREO, int ID_EMPRESA) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_EMPRESA SET "
                    + "NOMBRE_COMERCIAL = '" + NOMBRE_COMERCIAL + "', "
                    + "NIT =              '" + NIT + "', "
                    + "DIRECCION =        '" + DIRECCION + "', "
                    + "TELEFONO =         '" + TELEFONO + "', "
                    + "CORREO =           '" + CORREO + "'"
                    + "WHERE ID_EMPRESA =  " + ID_EMPRESA + " ");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminarEmpresa(int ID_EMPRESA) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_EMPRESA WHERE ID_EMPRESA = " + ID_EMPRESA + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Empresa> listarEmpresa() {
        Empresa e = null;
        ArrayList<Empresa> lista = new ArrayList<Empresa>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_EMPRESA");

            while (rs.next()) {
                e = new Empresa(rs.getString("NOMBRE_COMERCIAL"),
                        rs.getString("NIT"),
                        rs.getString("DIRECCION"),
                        rs.getString("TELEFONO"),
                        rs.getString("CORREO"),
                        rs.getInt(1));
                lista.add(e);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Empresa listarEmpresaPorID(int ID_EMPRESA) {
        Empresa e = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_EMPRESA WHERE ID_EMPRESA = " + ID_EMPRESA + "");

            while (rs.next()) {
                e = new Empresa(rs.getString("NOMBRE_COMERCIAL"),
                        rs.getString("NIT"),
                        rs.getString("DIRECCION"),
                        rs.getString("TELEFONO"), rs.getString("CORREO"),
                        rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return e;
    }
}
