package wsServicios;

import Modelo.Incidencia;
import Modelo.csIncidencia;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvIncidencia")
public class srvIncidencia {

    @WebMethod(operationName = "InsertarIncidencia")
    public int insertarIncidencia(@WebParam(name = "ID_HARDWARE") int ID_HARDWARE, @WebParam(name = "ID_SOFTAWARE") int ID_SOFTWARE, @WebParam(name = "FECHA_INCIDENCIA") String FECHA_INCIDENCIA, @WebParam(name = "ESTADO") String ESTADO) {
        csIncidencia e = new csIncidencia();
        return e.insertarIncidencia(ID_HARDWARE, ID_SOFTWARE, FECHA_INCIDENCIA, ESTADO);
    }

    @WebMethod(operationName = "ActualizarIncidencia")
    public int actualizarIncidencia(@WebParam(name = "ID_HARDWARE") int ID_HARDWARE, @WebParam(name = "ID_SOFTAWARE") int ID_SOFTWARE, @WebParam(name = "FECHA_INCIDENCIA") String FECHA_INCIDENCIA, @WebParam(name = "ESTADO") String ESTADO, @WebParam(name = "ID_INCIDENCIA") int ID_INCIDENCIA) {
        csIncidencia e = new csIncidencia();
        return e.actualizarIncidencia(ID_HARDWARE, ID_SOFTWARE, FECHA_INCIDENCIA, ESTADO, ID_INCIDENCIA);
    }

    @WebMethod(operationName = "Eliminar")
    public int eliminarIncidencia(@WebParam(name = "ID_INCIDENCIA") int ID_INCIDENCIA) {
        csIncidencia e = new csIncidencia();
        return e.eliminarIncidencia(ID_INCIDENCIA);
    }

    @WebMethod(operationName = "Listar")
    public ArrayList<Incidencia> listarIncidencia() {
        csIncidencia e = new csIncidencia();
        return e.listarIncidencia();
    }

    @WebMethod(operationName = "ListarPorID")
    public Incidencia listarIncidenciaPorID(@WebParam(name = "ID_INCIDENCIA") int ID_INCIDENCIA) {
        csIncidencia e = new csIncidencia();
        return e.listarIncidenciaPorID(ID_INCIDENCIA);
    }
}
