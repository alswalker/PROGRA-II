package wsServicios;

import Modelo.Empleado;
import Modelo.csEmpleado;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvEmpleado")
public class srvEmpleado {

    @WebMethod(operationName = "InsertarEmpleado")
    public int insertarEmpleado(@WebParam(name = "ID_USUARIO") int ID_USUARIO, @WebParam(name = "NOMBRES") String NOMBRES, @WebParam(name = "IDENTIFICACION") String IDENTIFICACION, @WebParam(name = "CORREO") String CORREO, @WebParam(name = "PUESTO") String PUESTO) {
        csEmpleado e = new csEmpleado();
        return e.insertarEmpleado(ID_USUARIO, NOMBRES, IDENTIFICACION, CORREO, PUESTO);
    }

    @WebMethod(operationName = "ActualizarEmpleado")
    public int actualizarEmpleado(@WebParam(name = "ID_USUARIO") int ID_USUARIO, @WebParam(name = "NOMBRES") String NOMBRES, @WebParam(name = "IDENTIFICACION") String IDENTIFICACION, @WebParam(name = "CORREO") String CORREO, @WebParam(name = "PUESTO") String PUESTO, @WebParam(name = "ID_EMPLEADO") int ID_EMPLEADO) {
        csEmpleado e = new csEmpleado();
        return e.actualizarEmpleado(ID_USUARIO, NOMBRES, IDENTIFICACION, CORREO, PUESTO, ID_EMPLEADO);
    }

    @WebMethod(operationName = "EliminarEmpleado")
    public int eliminarEmpleado(@WebParam(name = "ID_EMPLEADO") int ID_EMPLEADO) {
        csEmpleado e = new csEmpleado();
        return e.eliminarEmpleado(ID_EMPLEADO);
    }

    @WebMethod(operationName = "ListarEmpleado")
    public ArrayList<Empleado> listarEmpleado() {
        csEmpleado e = new csEmpleado();
        return e.listarEmpleado();
    }

    @WebMethod(operationName = "ListarEmpleadoPorID")
    public Empleado listarEmpleadoPorID(@WebParam(name = "ID_EMPLEADO") int ID_EMPLEADO) {
        csEmpleado e = new csEmpleado();
        return e.listarEmpleadoPorID(ID_EMPLEADO);
    }
}
