package wsServicios;

import Modelo.AtencionIncidencia;
import Modelo.csAtencionIncidencia;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvAtencionIncidencia")
public class srvAtencionIncidencia {

    //insertar
    @WebMethod(operationName = "Insertar")
    public int insertarAtencionIncidencia(@WebParam(name = "ID_INCIDENCIA") int ID_INCIDENCIA,
            @WebParam(name = "ID_SOLICITANTE") int ID_SOLICITANTE,
            @WebParam(name = "ID_EMPLEADO") int ID_EMPLEADO,
            @WebParam(name = "FECHA_ATENCION_IN") String FECHA_ATENCION_IN,
            @WebParam(name = "OBSERVACIONES") String OBSERVACIONES,
            @WebParam(name = "ESTADO") String ESTADO) {
        csAtencionIncidencia a = new csAtencionIncidencia();
        return a.insertarAtencionIncidencia(ID_INCIDENCIA, ID_SOLICITANTE, ID_EMPLEADO, FECHA_ATENCION_IN, OBSERVACIONES, ESTADO);
    }

    //actualizar
    @WebMethod(operationName = "Actualizar")
    public int actualizarAtencionIncidencia(@WebParam(name = "ID_INCIDENCIA") int ID_INCIDENCIA,
            @WebParam(name = "ID_SOLICITANTE") int ID_SOLICITANTE,
            @WebParam(name = "ID_EMPLEADO ") int ID_EMPLEADO,
            @WebParam(name = "FECHA_ATENCION_IN") String FECHA_ATENCION_IN,
            @WebParam(name = "OBSERVACIONES ") String OBSERVACIONES,
            @WebParam(name = "ESTADO ") String ESTADO,
            @WebParam(name = "ID_ATENCION_IN ") int ID_ATENCION_IN) {
        csAtencionIncidencia a = new csAtencionIncidencia();
        return a.actualizarAtencionIncidencia(ID_INCIDENCIA, ID_SOLICITANTE, ID_EMPLEADO, FECHA_ATENCION_IN, OBSERVACIONES, ESTADO, ID_ATENCION_IN);
    }

    //eliminar
    @WebMethod(operationName = "Eliminar")
    public int eliminarAtencionIncidencia(@WebParam(name = "ID_ATENCION_IN") int ID_ATENCION_IN) {
        csAtencionIncidencia a = new csAtencionIncidencia();
        return a.eliminarAtencionIncidencia(ID_ATENCION_IN);
    }

    //lista 
    @WebMethod(operationName = "Listar")
    public ArrayList<AtencionIncidencia> listarAtencionIncidencia() {
        csAtencionIncidencia a = new csAtencionIncidencia();
        return a.listarAtencionIncidencia();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarPorID")
    public AtencionIncidencia listarAtencionIncidenciaPorID(@WebParam(name = "ID_ATENCION_IN") int ID_ATENCION_IN) {
        csAtencionIncidencia a = new csAtencionIncidencia();
        return a.listarAtencionIncidenciaPorID(ID_ATENCION_IN);
    }
}