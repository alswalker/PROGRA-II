package wsServicios;

import Modelo.Usuario;
import Modelo.csUsuario;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvUsuario")
public class srvUsuario {

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "InsertarUsuario")
    public int insertarUsuario(@WebParam(name = "USUARIO") String USUARIO,
            @WebParam(name = "CONTRASEÑA") String CONTRASEÑA) {
        csUsuario u = new csUsuario();
        return u.insertarUsuario(USUARIO, CONTRASEÑA);
    }

    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "ActualizarUsuario")
    public int actualizarUsuario(@WebParam(name = "USUARIO") String USUARIO,
            @WebParam(name = "CONTRASEÑA") String CONTRASEÑA,
            @WebParam(name = "ID_USUARIO") int ID_USUARIO) {
        csUsuario u = new csUsuario();
        return u.actualizarUsuario(USUARIO, CONTRASEÑA, ID_USUARIO);
    }

    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "EliminarUsuario")
    public int eliminarUsuario(@WebParam(name = "ID_USUARIO") int ID_USUARIO) {
        csUsuario u = new csUsuario();
        return u.eliminarUsuario(ID_USUARIO);
    }

    /*--------METODO LIST--------*/
    @WebMethod(operationName = "ListarUsuario")
    public ArrayList<Usuario> listarUsuario() {
        csUsuario u = new csUsuario();
        return u.listarUsuario();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarUsuarioPorID")
    public Usuario listarUsuarioPorID(@WebParam(name = "ID_USUARIO") int ID_USUARIO) {
        csUsuario u = new csUsuario();
        return u.listarUsuarioPorID(ID_USUARIO);
    }
}
